<h1 align="center">Typora foresee theme</h1>

![](https://img.shields.io/badge/Author-passwordgloo-blueviolet?logo=github&amp;style=flat)&emsp;![](https://img.shields.io/badge/Version-0.0.5.8-orange?logo=markdown&amp;style=flat)&emsp;![](https://img.shields.io/github/last-commit/passwordgloo/typora-foresee-theme?logo=Git)&emsp;![](https://img.shields.io/badge/passwordgloo-11-white?logo=bilibili&logoColor=white&labelColor=FE7398&amp;style=flat)&emsp;![](https://img.shields.io/badge/麦田守望者-92-white?logo=zhihu&logoColor=white&labelColor=0084ff&amp;style=flat)&emsp;![](https://img.shields.io/badge/dynamic/json?color=white&label=%E7%BD%91%E6%98%93%E4%BA%91%E9%9F%B3%E4%B9%90&query=%24.data.totalSubs&url=https%3A%2F%2Fapi.spencerwoo.com%2Fsubstats%2F%3Fsource%3DneteaseMusic%26queryKey%3D1732207004&logo=data:image/svg+xml;base64,PHN2ZyBpZD0i5Zu+5bGCXzEiIGRhdGEtbmFtZT0i5Zu+5bGCIDEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmlld0JveD0iMCAwIDQyNS4yIDQyNS4yIj48ZGVmcz48c3R5bGU+LmNscy0xe2ZpbGw6I2ZmZjt9PC9zdHlsZT48L2RlZnM+PHRpdGxlPue9keaYk+S6kTwvdGl0bGU+PHBhdGggY2xhc3M9ImNscy0xIiBkPSJNMzIwLjYsNDI1LjJIMTA1LjQyYy0xLjY5LS4yLTMuNC0uNDQtNS4wOS0uNjEtOC4xNy0uODctMTYuNDMtMS4xOS0yNC40OC0yLjY4QzUxLjQxLDQxNy40LDMxLjc3LDQwNSwxNy40NSwzODQuNTYsNy40NSwzNzAuMjksMi44NSwzNTQuMTUsMS4zMywzMzcsLjgxLDMzMS4yNi40NCwzMjUuNTEsMCwzMTkuNzdWMTA3LjA4Yy4yMi0yLjQxLjQzLTQuODIuNjctNy4yMi44My04LjE3LDEuMTYtMTYuNDMsMi41OS0yNC40OSw2LjQ1LTM2LjUyLDM0LjQ5LTY0LjY0LDcxLTcxLjkxQzg5LjQuNDYsMTA0LjcuMSwxMjAsLjA4LDE4NC44MiwwLDI0OS42MS0uMSwzMTQuNC4xN2ExODEuMTIsMTgxLjEyLDAsMCwxLDM0Ljc4LDNjMzYuOTUsNy4zOCw2MS4xOSwyOS4zMyw3MS41Nyw2NS44LDQsMTQuMTgsNC4zNSwyOC44OSw0LjM4LDQzLjUxcS4xNSwxMDAuMDgsMCwyMDAuMTdBMjQzLjU4LDI0My41OCwwLDAsMSw0MjIuNzgsMzQ2Yy0zLjksMjcuMjMtMTcuNjMsNDguNTEtNDAuOCw2My40Ny0xMy43OSw4LjktMjkuMjIsMTIuOTQtNDUuNCwxNC40MUMzMzEuMjIsNDI0LjM3LDMyNS44Nyw0MjQuNzcsMzIwLjYsNDI1LjJaTTI2Ni44NCwxNjQuNzZjMS42OC40MiwyLjY3LjYxLDMuNjIuOTFBNjQuMzgsNjQuMzgsMCwwLDEsMjk2LjA5LDE4MWMzMSwzMC4zNywzMi40Nyw4Mi4zOSwyLjUyLDExNS4xMy0yNy40MSwzMC02MS44NSw0MS41LTEwMS42OSwzNC40OS02OS40Mi0xMi4xOC0xMTAuMS04NS40NS04NC4xMS0xNTAuODksMTEuNTktMjkuMTcsMzIuNDMtNDkuNiw2MS4yNi02Miw5LTMuODYsMTIuODYtMTIuODQsOS4zNC0yMS4xNy0zLjYxLTguNTQtMTIuNzYtMTItMjEuODktOC4yMkExNDIuOTIsMTQyLjkyLDAsMCwwLDc2LjY5LDI1M0M5MSwzMTUsMTQ1Ljg3LDM2MS4xMywyMDkuMTgsMzY0LjE4YzM2LjE3LDEuNzQsNjktOC4zMiw5Ni44Mi0zMS4zOCwzOS41MS0zMi43MSw1NC44My03NC42MSw0MS43MS0xMjQuODEtOC4yNi0zMS42MS0yNy42NS01NS4yMi01Ny44OC02OWExMDIuNTIsMTAyLjUyLDAsMCwwLTI5LjU2LThjLTEtLjE0LTIuNjUtLjgxLTIuODUtMS41NGExOTMsMTkzLDAsMCwxLTQuODktMjAuMSwxNSwxNSwwLDAsMSw4LjMzLTE1LjksMTYsMTYsMCwwLDEsMTcuOSwyLjQ0YzEuNjEsMS40LDMsMyw0LjYyLDQuNDNhMTYsMTYsMCwwLDAsMjIuNTUtMS4zOC42OS42OSwwLDAsMCwuMTEtLjEzYzUuNTMtNi40Miw1LjM0LTE1LjE5LTEtMjIuMTRhNDksNDksMCwwLDAtNzUuNDgsMi44M2MtMTAsMTMuMTMtMTAuOTMsMjgtNyw0My40OS44MSwzLjIsMS42NSw2LjQsMi40NCw5LjM5YTcuMzcsNy4zNywwLDAsMS0uNjEuNWMtMS4yNy4zNi0yLjUzLjcyLTMuOCwxLTE4LjgyLDQuODgtMzUsMTQuMjUtNDcuMzMsMjkuMzYtMTkuMjksMjMuNTctMjUuNDUsNDkuOTMtMTQuMSw3OC44MiwxMi40OSwzMS43OSw0NS45Miw0Ny44Myw3Ny41LDM3Ljc4LDI4LjA4LTguOTQsNDQuNzMtMzUuMzQsNDIuMTEtNjUuMjItLjgzLTkuNjEtMy42Ni0xOS4wOC01LjkyLTI4LjUzQzI3MS4xNiwxNzkuMTUsMjY5LDE3Mi4zMSwyNjYuODQsMTY0Ljc2WiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCAwKSIvPjxwYXRoIGNsYXNzPSJjbHMtMSIgZD0iTTE4NS42OCwyMTEuNTJjMS0xNy44MywxMS44NS0zMi40OSwzMC4xNS00MS45Miw0LjcyLTIuNDQsMTAuMS0zLjU2LDE1LjE1LTUuMzQsMS43NC0uNjEsMi41Mi0uMTYsMywxLjY4LDMuOTMsMTQuMzcsOC4wOSwyOC42OCwxMS44OCw0My4xMWEzNy4zOSwzNy4zOSwwLDAsMS0uNzYsMjMuMDhjLTcuMzgsMTkuNzctMzIuNDMsMjUuMjUtNDcuODUsMTAuNDdDMTg5LjM0LDIzNSwxODUuNiwyMjUuNjcsMTg1LjY4LDIxMS41MloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgMCkiLz48L3N2Zz4=&labelColor=d62f2e)

<p align="center"><a href="https://github.com/passwordgloo/Typora-foresee-theme/blob/study/Readme.md">Readme</a>&nbsp;|&nbsp;<a href="https://github.com/passwordgloo/Typora-foresee-theme/blob/study/CHANGELOG.md">CHANGELOG</a>&nbsp;|&nbsp;<a href="https://github.com/passwordgloo/Typora-foresee-theme/blob/study/LICENSE">LICENSE</a></p>

> ![](https://user-images.githubusercontent.com/90091016/271819148-aa5cd28e-6876-4729-9865-e29001e1147c.png) Via [中文版本](ReadmeCN.md) for an introduction and more details.

---

## Thanks

Based on default `night` theme modifies my theme

Selected textstyle is inspired by [typora-dyzj-theme](https://github.com/muggledy/typora-dyzj-theme) 

## How to use

1. Clone this repository or [download zip](https://github.com/passwordgloo/Typora-foresee-theme/archive/refs/heads/study.zip)
2. Typora open Settings>Apperance>Theme，click the button`open theme folder`
3. Copy and paste files into the theme folder

## Features

- Automatically switch theme mode based on the appearance of the system
- User defined color configuration
- Modular design approach adapts to diverse needs
- Use `scss` format substitute original `css`

## BREAKING CHANGES

### Bar

>[!important]
>Only for gradient.css

```html
<section alt="note">note text</section><br>
<section alt="info">info text</section><br>
<section alt="tip">tip text</section><br>
<section alt="warning">warning text</section><br>
<section alt="caution">caution text</section><br>
<section alt="important">important text</section>
```

![2025 08 02 11.51.24de389e826e079b8d](https://origin.picgo.net/2025/09/21/2025-08-02-11.51.24de389e826e079b8df9f0a0a886f6de35.png)

> [!tip]
>
> Need icon ? We also provide icon to beautify styles
>

```html
<section alt="note-icon">note-icon text</section><br>
<section alt="info-icon">info-icon text</section><br>
<section alt="tip-icon">tip-icon text</section><br>
<section alt="warning-icon">warning-icon text</section><br>
<section alt="caution-icon">caution-icon text</section><br>
<section alt="important-icon">important-icon text</section>
```

![2025 08 02 11.52.23042330592300b6cf](https://origin.picgo.net/2025/09/21/2025-08-02-11.52.23042330592300b6cf8034f7739dd8bf5c.png)

### Todo list

>[!note]
>use gradient style

![2025 07 27 09.39.10f95ad407fbd7ba1f](https://origin.picgo.net/2025/09/21/2025-07-27-09.39.10f95ad407fbd7ba1fe9f2b531f82f26bf.png)

### Code Style

#### Inline code

>[!note]
>Use Mac keyboard style for line code and `kbd` element

inline code like this

![PixPin 2024 10 07 10 52d4e14471431780c4](https://origin.picgo.net/2025/09/21/PixPin_2024-10-07_10-52d4e14471431780c4c2ebc19b2f73364e.png)

`kbd` element like this

![PixPin 2024 10 07 11 066d7ce5c39f4222b9](https://origin.picgo.net/2025/09/21/PixPin_2024-10-07_11-066d7ce5c39f4222b9e63ad5542d88ea1a.png)

>[!important]
> Please go to Preferences>Markdown> to turn on `displaying line numbers` for a better experience

1. Support custom cursor color

![PixPin 2024 08 18 00 01 001bbf1d3c1f79dab1c31037217208932b](https://origin.picgo.net/2025/09/21/PixPin_2024-08-18_00-01-001bbf1d3c1f79dab1c31037217208932b5b3e235a12c577cc.gif)

2. Different code style based on the appearance of the system

![PixPin 2024 08 18 17 20 320212612d5f2cd57c](https://origin.picgo.net/2025/09/21/PixPin_2024-08-18_17-20-320212612d5f2cd57c51b64967e582fe11.png)

![PixPin 2024 08 18 17 20 09e3d823ee3bc3f30f](https://origin.picgo.net/2025/09/21/PixPin_2024-08-18_17-20-09e3d823ee3bc3f30f4c544ab3dea15d95.png)

### Blockquote

1. Default blockquote style use theme single color

You can type `>` to insert blockquote by default

![2024 07 24 21.25.2306902135529210e2](https://origin.picgo.net/2025/09/21/2024-07-24-21.25.2306902135529210e22e349302e9552cca.png)

2. Blockquote style supports linear-gradient

>[!warning]
>
>Only for gradient style

```html
<blockquote alt = 'green'>green</blockquote>
<blockquote alt = 'blue'>blue</blockquote>
<blockquote alt = 'orange'>orange</blockquote>
<blockquote alt = 'purple'>purple</blockquote>
<blockquote alt = 'red'>red</blockquote>
```

![2024 12 05 23.25.517d5d3904c12445ac](https://origin.picgo.net/2025/09/21/2024-12-05-23.25.517d5d3904c12445ac4a4bd6139f62d86f.png)

3. Github blockquote style

```markdown
> [!note]
>
> Note text

> [!tip]
>
> Tip text

> [!warning]
>
> Warning text

> [!caution]
>
> Caution text

> [!important]
>
> Important text
```

![2024 12 05 23.20.19eaddd2d09531df4b](https://origin.picgo.net/2025/09/21/2024-12-05-23.20.19eaddd2d09531df4b250a63967ffc55a2.png)

4. Blockquote style can change its color when it close to heading

![PixPin 2025 07 27 10 01 41757ca0a5b84fad3c](https://origin.picgo.net/2025/09/21/PixPin_2025-07-27_10-01-41757ca0a5b84fad3c9f84d2b5e43380cf.gif)

### Title

>[!note]
>Redesign header style and its focus mode

![PixPin 2025 07 27 10 12 21e2176109d4be271d](https://origin.picgo.net/2025/09/21/PixPin_2025-07-27_10-12-21e2176109d4be271d2d4b254cc715edfd.gif)

![PixPin 2025 07 27 10 48 17339ea527282addc7](https://origin.picgo.net/2025/09/21/PixPin_2025-07-27_10-48-17339ea527282addc73dc168721c1867b3.gif)

### Badge

![2025 07 27 10.47.212f2535ab49083f01](https://origin.picgo.net/2025/09/21/2025-07-27-10.47.212f2535ab49083f014e103d1ea26d662d.png)

## Todo

- [x] add more animation style
- [ ] add pdf input style
- [x] Distinguish between dark and light reference block styles

## Personalities

>[!warning]
>The css file located in the root directory of the files is compressed by default. 
>
>Please modify the `scss` file located in the `foresee` folder so that you can make your own personal style

```scss
$display: (
  light:#FFF,
  dark:#666
);

$article: (
  light:#FFF,
  dark:#323232
);

$sidebar: (
  light: #F2F2F2,
  dark: #3E3E3E
);

$textColor: (
  light:#DEDEDE,
  dark:#323232
);

$tomato: #ff6347;

$purple: #ff00ff;

$blue: #00bfff;

$green: #00cd66;

$orange: #ff8c00;

$red: #f14669;

/* Gradient colors */

$black-gradient: #596164, #646c70, #6f787d, #7a8389, #868f96;

$blue-gradient: #005bea, #007bf9, #0097ff, #00affe, #00c6fb;

$tomato-gradient: #ed2842, #f33d58, #f7506d, #fa6181, #fb7294;

$orange-gradient: #e9a11a, #eab211, #e8c40a, #e5d50f, #dee71d;

$purple-gradient: #c471f5, #d66feb, #e46fe1, #f06fd7, #fa71cd;

$green-gradient: #0ba360, #39b05d, #57bc5a, #72c856, #8ed451;

/*  You can change theme color and theme gradient color */

$themeColor: $orange;

$focusColor: $green;

$themeGradient:$orange-gradient;

$focusGradient:$green-gradient;

:root {
  --bg-color: map-get($article, light);
  --select-text-bg-color: map-get($display, dark);
  --text-color: map-get($textColor, dark);
  --primary-color: $themeColor;
  --rawblock-edit-panel-bd: map-get($sidebar, light);
  --item-hover-bg-color: $themeColor;
  --control-text-hover-color: $themeColor;

  --md-char-color: rgba(72, 93, 108, 0.75);
  --meta-content-color: var(--md-char-color);
  --primary-btn-text-color: var(--text-color);
  --active-file-text-color: $themeColor;
}

// Custom fonts and style

$border-radius: 6px;

$font-family: "Microsoft YaHei", "PingFang SC", "Arial", "sans-serif";

/* you can change default page width
#write {
  max-width: 914px;
} 
*/
```

## Tutorial

Visit [wiki](https://github.com/passwordgloo/Typora-foresee-theme/wiki/English-Tutorial) to learn tutorial

## Preview

### Gradient style

![PixPin 2025 08 02 11 46 21e6395e3ffef84934](https://origin.picgo.net/2025/09/21/PixPin_2025-08-02_11-46-21e6395e3ffef84934b3807a8d183780bf.png)

### Classic Style

![PixPin 2025 08 02 11 45 401e2f70479b054970](https://origin.picgo.net/2025/09/21/PixPin_2025-08-02_11-45-401e2f70479b0549701839ba43e56bad3a.png)

### Glass Style

![PixPin 2025 08 02 11 44 48cb6ef2e69994ffc9](https://origin.picgo.net/2025/09/21/PixPin_2025-08-02_11-44-48cb6ef2e69994ffc9e9cb178a773c5545.png)

## Purpose of use

*   classify my files

*   left the footprint of learning

*   enlighten other's thoughts
